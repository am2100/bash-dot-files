# vim-haskell-indent [![Build Status](https://travis-ci.org/itchyny/vim-haskell-indent.svg)](https://travis-ci.org/itchyny/vim-haskell-indent)
## The best indent plugin for Haskell in Vim

![vim-haskell-indent](https://raw.githubusercontent.com/wiki/itchyny/vim-haskell-indent/image/1.gif)

![vim-haskell-indent](https://raw.githubusercontent.com/wiki/itchyny/vim-haskell-indent/image/2.gif)

![vim-haskell-indent](https://raw.githubusercontent.com/wiki/itchyny/vim-haskell-indent/image/3.gif)

## Installation
Install with your favorite plugin manager.

## Author
itchyny (https://github.com/itchyny)

## License
This software is released under the MIT License, see LICENSE.
