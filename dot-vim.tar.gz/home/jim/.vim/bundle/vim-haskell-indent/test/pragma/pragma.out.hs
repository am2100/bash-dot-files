{-# LANGUAGE X,
             Y,
             Z #-}
{-# LANGUAGE X
           , Y
           , Z #-}
{-# LANGUAGE X,
             Y,
             Z
#-}
{-# LANGUAGE X
           , Y
           , Z
#-}
{-# LANGUAGE A #-}
{-# LANGUAGE B #-}
{-# LANGUAGE C #-}
