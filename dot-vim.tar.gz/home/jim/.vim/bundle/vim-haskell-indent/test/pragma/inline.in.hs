instance X Y where
{-# INLINE foo #-}
foo = 0
