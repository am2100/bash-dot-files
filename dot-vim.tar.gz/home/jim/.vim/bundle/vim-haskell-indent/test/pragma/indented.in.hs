f x = q
where q = w
{-# RULES
"q"
#-}
