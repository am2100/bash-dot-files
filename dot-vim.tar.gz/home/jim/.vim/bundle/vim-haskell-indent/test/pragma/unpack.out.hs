data T = T {-# UNPACK #-} !X
           {-# UNPACK #-} !X
