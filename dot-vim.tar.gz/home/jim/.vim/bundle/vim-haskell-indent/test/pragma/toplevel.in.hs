f x = q
where q = w

g x = q
{-# RULES
"f/g"
#-}
