{-# LANGUAGE X,
Y,
Z #-}
{-# LANGUAGE X
, Y
, Z #-}
{-# LANGUAGE X,
Y,
Z
<ESC>a#-}
{-# LANGUAGE X
, Y
, Z
<ESC>a#-}
{-# LANGUAGE A #-}
{-# LANGUAGE B #-}
{-# LANGUAGE C #-}
