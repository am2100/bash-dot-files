z = (x, y)
where x = [ 1, 2, 3 ]
y = [ 1, 2, 3 ]
