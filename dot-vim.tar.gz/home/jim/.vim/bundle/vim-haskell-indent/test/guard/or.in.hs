f xs ys
| null xs || null ys = []
| otherwise = []
