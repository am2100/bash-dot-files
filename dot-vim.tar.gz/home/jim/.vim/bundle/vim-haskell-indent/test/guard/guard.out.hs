f x | x > 10 = 10
    | x < 0 = 0
    | otherwise = x
g x = 10
