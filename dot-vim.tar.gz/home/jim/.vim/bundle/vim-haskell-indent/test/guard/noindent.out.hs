f x | x > 10 = x
f 0 = -100
f x | otherwise = x
