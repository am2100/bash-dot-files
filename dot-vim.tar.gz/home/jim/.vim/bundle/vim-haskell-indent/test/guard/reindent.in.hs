f x | x > 10 = 10
<ESC>a| x < 0 = 0
<ESC>a| otherwise = x
