f x | x > 10 = x
<ESC>af 0 = -100
f x | otherwise = x
