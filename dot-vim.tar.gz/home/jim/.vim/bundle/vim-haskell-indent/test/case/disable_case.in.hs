<ESC>:let g:haskell_indent_disable_case = 1
af x = case x of
1 -> 0
2 -> 1
_ -> x
