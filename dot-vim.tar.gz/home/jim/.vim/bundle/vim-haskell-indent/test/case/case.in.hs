f x = case x of
1 -> 0
2 -> 1
_ -> x
