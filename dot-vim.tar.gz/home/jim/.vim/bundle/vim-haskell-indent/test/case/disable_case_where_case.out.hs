f = g
  where g x = case x of
          1 -> 1
          2 -> 0
          _ -> x
        h x = x
