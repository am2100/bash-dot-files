h = f
  where
    f x = case x of
      1 -> let y = g x
               in y
      4 -> let y = g x
               in y
      _ -> let y = g x
               in y
