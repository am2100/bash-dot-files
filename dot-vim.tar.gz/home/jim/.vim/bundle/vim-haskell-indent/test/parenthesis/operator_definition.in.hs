-- foo bar
(<>) x y = x + y
(++) x y = x * y
