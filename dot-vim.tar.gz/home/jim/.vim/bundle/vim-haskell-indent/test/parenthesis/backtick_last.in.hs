let f x y z = x `foo`
y `bar`
z
