foo a b =
  let (c, d) = f a b
      (e, f) = g c d
      in f e
