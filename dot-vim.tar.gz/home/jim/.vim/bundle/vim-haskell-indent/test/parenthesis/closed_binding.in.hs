f x y z
  = [ x,
y,
z ]
g x = x
