let f x y z = X [
x,
y,
z
]
