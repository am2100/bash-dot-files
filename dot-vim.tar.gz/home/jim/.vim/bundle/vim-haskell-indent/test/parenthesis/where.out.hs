g = f
  where f x = [ y | y <- [s..x] ]
        s = 0
