let foo = Foo {
      foo = 100,
      bar = Bar {
        bar = 200
      },
      baz = [
        1,
        2,
        3
      ],
      qux = Qux {
      }
    }
