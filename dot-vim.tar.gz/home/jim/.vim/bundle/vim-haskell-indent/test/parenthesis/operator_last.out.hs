let f x y z = x +
      y +
      z
