f = g
where g =
map
