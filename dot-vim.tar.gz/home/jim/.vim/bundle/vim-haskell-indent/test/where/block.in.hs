x = y
where y = 10
z = 10
