f x = q
  where q = z
          where z = 10

        p = w

w = 10
