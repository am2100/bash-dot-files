x = y where y = z
z = 10
