f x = q



<ESC>awhere q = 10
