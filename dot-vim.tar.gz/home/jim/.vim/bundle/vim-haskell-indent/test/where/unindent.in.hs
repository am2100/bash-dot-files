f x = q
where q = 20

g x = x
