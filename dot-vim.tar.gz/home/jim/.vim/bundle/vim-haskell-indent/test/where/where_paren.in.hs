f x = y 0
where y z | z > 10 = 10
| otherwise = (10 + 20)
q = 20

p = 10
