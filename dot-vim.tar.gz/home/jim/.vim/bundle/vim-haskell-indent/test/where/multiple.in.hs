x = y
where
y = z
where z = 10
