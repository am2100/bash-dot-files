f x = q



  where q = 10
