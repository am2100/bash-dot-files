x = y
<ESC>awhere y = 10
