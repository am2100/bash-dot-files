x = y where
y = 10
