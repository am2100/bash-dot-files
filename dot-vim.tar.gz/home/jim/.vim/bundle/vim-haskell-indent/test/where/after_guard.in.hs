f x | x > 10 = 10
| x < 0 = 0
| otherwise = x
where y = 10
z = 10

g x = 10
