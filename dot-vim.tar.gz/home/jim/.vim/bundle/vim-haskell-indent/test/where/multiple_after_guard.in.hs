x = y
where
y | False = z
| otherwise = 0
where z = 10
