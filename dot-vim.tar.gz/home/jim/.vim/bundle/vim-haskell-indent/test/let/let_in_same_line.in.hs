f = let x = 0 in x
where x = let y = 1 in y
y = let z = 1 in z
z = let w = 1 in w
w = let x = 1 in x
