f = let x = 0
    y = 1
in let z = 2
    u = 3
in (x, y, z, u)
