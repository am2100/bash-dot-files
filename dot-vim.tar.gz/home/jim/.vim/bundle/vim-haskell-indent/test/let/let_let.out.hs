f = do
  let x = 0
  let y = 0
  let z = 0
  return (x, y, z)
