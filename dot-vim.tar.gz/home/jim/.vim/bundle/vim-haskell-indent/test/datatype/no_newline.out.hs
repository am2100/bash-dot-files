data X = A | B | C
       deriving Eq
