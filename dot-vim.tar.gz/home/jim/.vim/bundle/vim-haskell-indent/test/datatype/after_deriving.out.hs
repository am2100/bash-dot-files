data X a = L a
         | N
         deriving Eq
f x = x
