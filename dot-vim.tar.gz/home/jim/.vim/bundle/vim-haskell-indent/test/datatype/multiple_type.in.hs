data X = A | B
data Y = C | D
type W = X
data Z = E | F
