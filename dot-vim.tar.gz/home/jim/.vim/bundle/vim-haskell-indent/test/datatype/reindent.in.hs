data X a = L a
<ESC>a| N
<ESC>aderiving Eq
