data X a where
  I :: Int -> X Int
