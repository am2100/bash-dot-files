data X a = L a
         | N
         deriving ( Eq,
                    Ord,
                    Show )
f x = x
