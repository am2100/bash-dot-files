data X
  = X
  | Y
  | Z
