data X a = L a
         | N
         deriving (Eq, Show, Ord)
f x = x
