data X = A | B
data Y = C | D
data Z = E | F
