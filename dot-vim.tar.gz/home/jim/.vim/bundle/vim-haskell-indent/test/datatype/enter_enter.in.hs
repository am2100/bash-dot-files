data X a = L a
| N

f x = x
