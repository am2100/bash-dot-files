data X = X { foo :: Int,
             bar :: String,
           } deriving (Eq, Show, Ord)
f x = x
