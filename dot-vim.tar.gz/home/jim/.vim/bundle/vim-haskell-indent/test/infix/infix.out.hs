infixr 9  .
infixr 5  ++
infixl 4  <$
infix  2  `foo`
infixl 1  >>, >>=
infixr 1  =<<

infixr 0  $, $!


infixl 4 <*>, <*, *>, <**>
