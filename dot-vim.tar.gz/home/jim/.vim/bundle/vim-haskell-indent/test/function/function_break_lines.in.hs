g = f
where
f = \x ->
\y ->
(x, y)
