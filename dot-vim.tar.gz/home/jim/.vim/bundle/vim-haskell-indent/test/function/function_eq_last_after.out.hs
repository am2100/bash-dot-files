q = 0
  where
    f x =
      x
    g x = x
    h x =
      (x)
    i = 0
    j x =
      [ x | x <- [0..10] ]
    k = 0
