g = f
where
f :: Int -> Int
f 0
  = 1
f x
  = x
