<ESC>:set shiftwidth=8<CR>amain = do
print "hello"
