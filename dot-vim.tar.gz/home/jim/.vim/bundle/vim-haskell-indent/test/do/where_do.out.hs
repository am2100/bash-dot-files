z = x
  where f x = do
          print "hello"
