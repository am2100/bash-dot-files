<ESC>:set shiftwidth=4<CR>amain = do
print "hello"
