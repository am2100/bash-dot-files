z = let f x = do
print "hello"
in f 0
