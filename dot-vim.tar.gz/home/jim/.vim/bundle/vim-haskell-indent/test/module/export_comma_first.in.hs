module X
(
#if !defined(TESTING)
X
#else
X(..)
#endif

    -- f
, f

    -- g
, g

, h
) where
import Y
