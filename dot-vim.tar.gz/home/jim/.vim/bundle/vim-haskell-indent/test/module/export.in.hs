module X (foo) where
foo = 10
