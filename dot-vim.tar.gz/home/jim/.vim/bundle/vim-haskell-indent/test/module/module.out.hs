module X where
f x = 10
