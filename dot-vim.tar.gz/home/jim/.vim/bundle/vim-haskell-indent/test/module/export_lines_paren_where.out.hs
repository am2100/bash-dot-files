module X ( foo,
           bar,
           baz
  ) where
foo = 10
