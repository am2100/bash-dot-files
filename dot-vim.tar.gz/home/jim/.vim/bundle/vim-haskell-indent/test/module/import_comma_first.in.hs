import X
  (
#if !defined(TESTING)
X
#else
X(..)
#endif

    -- f
, f

    -- g
, g

, h
)
import Y
