instance X Y where
f = g
h = i

j = k
