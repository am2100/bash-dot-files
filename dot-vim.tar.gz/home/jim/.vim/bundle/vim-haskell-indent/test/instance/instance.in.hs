instance X Y where
f = g
