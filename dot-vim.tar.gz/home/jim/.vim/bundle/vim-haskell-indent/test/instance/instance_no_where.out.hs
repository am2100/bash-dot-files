instance X Y

f = g
