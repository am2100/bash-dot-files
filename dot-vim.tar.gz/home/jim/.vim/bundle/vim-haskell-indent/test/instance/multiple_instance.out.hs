instance X Y where
  f = g

instance W U where
  f = g
