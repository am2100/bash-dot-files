instance X Y

instance W U where
f = g
