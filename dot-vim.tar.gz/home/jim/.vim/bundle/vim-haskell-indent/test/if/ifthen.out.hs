f x = if x > 2
         then 2
         else 1
