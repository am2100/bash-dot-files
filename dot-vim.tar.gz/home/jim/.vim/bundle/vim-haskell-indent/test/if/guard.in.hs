f x | x > 1 = if x > 2
then 2
else 1
| otherwise = 0
