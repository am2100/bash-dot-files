class X where
  f = g
    where
      g = h
