class X where
foo :: Int
