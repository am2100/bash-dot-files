{-
foo
bar
baz
import X (
module
instance X Y where
if x
then y
else z
-}
