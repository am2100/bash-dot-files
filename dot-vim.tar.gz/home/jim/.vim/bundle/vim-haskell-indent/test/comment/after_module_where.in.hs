module Foo where
-- Foo
foo = 10
