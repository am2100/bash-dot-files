class X where
  foo :: Int


-- | Y
-- Y is something
-- nice.

class Y where
  bar :: Int
