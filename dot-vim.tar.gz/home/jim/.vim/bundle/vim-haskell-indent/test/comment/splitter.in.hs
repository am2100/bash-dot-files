class X where
foo :: Int

<ESC>a-- -----------
-- The Y class
class Y where
bar :: Int
