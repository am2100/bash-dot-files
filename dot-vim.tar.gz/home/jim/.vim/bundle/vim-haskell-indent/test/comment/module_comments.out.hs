module X
  (
    -- foo
    foo,
    -- bar
    bar
  ) where

