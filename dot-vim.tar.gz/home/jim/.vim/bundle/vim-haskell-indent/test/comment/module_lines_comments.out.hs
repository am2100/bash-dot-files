module X
  (
    -- foo
    foo,

    -- bar
    bar,

    -- baz
    baz
  ) where
