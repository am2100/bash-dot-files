data X = A
| B
<ESC>a-- | Y
-- Y is something
-- nice.
data Y = C
| D
