{---
foo
bar
baz
---}
f x = g x
  where g = id
