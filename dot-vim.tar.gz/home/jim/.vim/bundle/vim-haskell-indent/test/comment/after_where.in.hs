f x = q
where
-- q
q = 10
