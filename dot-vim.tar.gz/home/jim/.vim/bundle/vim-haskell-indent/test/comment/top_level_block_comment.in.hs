class X where
x :: Int
<ESC>a{- |
Another Class
-}
