class X where
  x :: Int
{- |
Another Class
-}
