instance X A where
foo :: Int
<ESC>a-- | B
-- B is something
-- nice.
instance Y B where
bar :: Int
