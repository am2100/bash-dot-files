class X where
  -- foo
  foo :: Int
  foo = 10
