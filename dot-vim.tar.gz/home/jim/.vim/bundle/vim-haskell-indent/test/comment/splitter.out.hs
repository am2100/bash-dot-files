class X where
  foo :: Int

-- -----------
-- The Y class
class Y where
  bar :: Int
