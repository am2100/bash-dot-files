{-
foo
bar

  a) foo
     foo
  b) bar
     bar

baa
-}
{-
foo
bar
  * @foo
  * @bar
baa
-}
{-
foo
bar
  > foo
  > bar
baa
-}
