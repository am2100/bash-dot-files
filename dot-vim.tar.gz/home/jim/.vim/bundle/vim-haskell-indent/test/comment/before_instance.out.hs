instance X A where
  foo :: Int
-- | B
-- B is something
-- nice.
instance Y B where
  bar :: Int
