{-
foo
bar

  a) foo
foo
<ESC>a  b) bar
bar

baa
-}
{-
foo
bar
  * @foo
* @bar
<ESC>abaa
-}
{-
foo
bar
  > foo
> bar
<ESC>abaa
-}
