{-
foo
bar
-}
{-
module
class X where
yyy
-}
