class X where
foo :: Int
<ESC>a-- | Y
-- Y is something
-- nice.
class Y where
bar :: Int
