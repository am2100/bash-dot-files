data X = A
       | B
-- | Y
-- Y is something
-- nice.
data Y = C
       | D
